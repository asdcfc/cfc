<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>index</title>
</head>
<body>
    <script src="/Public/css/common.css"></script>
<!-- 标题部分，分红色头部 白色菜单两部分 -->
    <header>
        <div class="header-top max-width">
            <img class="logo" src="images/logo.png" />
            <div class="header-top-content">
                <div class="user">user001</div>
                <div class="message">Message</div>
                <div class="logout">Login</div>
            </div>
        </div>

        <div class="header-menu max-width">
            <ul>
                <li class="current"><a href="###">首页</a></li>
                <li><a href="###">会员中心</a></li>
                <li><a href="###">产品展示</a></li>
                <li><a href="###">交易中心</a></li>
                <li><a href="###">交易记录</a></li>
                <li><a href="###">系统公告</a></li>
            </ul>
        </div>
    </header>
    <div class="index">
        <div class="index-content max-width">
            <div class="lang">
                <span class="lang-cn">中文版</span> /
                <span class="lang-en">English</span>
            </div>
            <div class="left-tips">
                <div class="title dark-red">珠海</div>
                <ul>
                    <li>是你身边的<span class="dark-red">专家</span></li>
                    <li>方便/快捷/安全</li>
                    <li>效力用户体验方便</li>
                    <li>增加用户体验的安全</li>
                </ul>
                <div class="index-btn">
                    <a href="" class="btn btn-dark-red">申请会员</a>
                </div>
            </div>
            <div class="center-logo">
                <img src="images/center.png" alt="">
            </div>
        </div>
    </div>
    <footer>
    <div class="warp max-width">
        <div class="foo">
            <div class="logo"><img src="images/bcenter.jpg" alt=""></div>
            <div class="text">JINRONGZHONGXIN</div>
        </div>

        <div class="foo">
            <div class="logo"><img src="images/bfeed.jpg" alt=""></div>
            <div class="text">JINSHENGCAIFU</div>
        </div>

        <div class="foo">
            <div class="logo"><img src="images/bzh.jpg" alt=""></div>
            <div class="text">ZHUHAIZHONGXIN</div>
        </div>
    </div>
</footer>
</body>
</html>