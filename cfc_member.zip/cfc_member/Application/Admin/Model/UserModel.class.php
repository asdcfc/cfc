<?php


namespace Admin\Model;

use Think\Model\RelationModel;

/**
 * Class UserModel
 * @package Admin\Model
 */
class UserModel extends RelationModel
{
    
}