<?php


namespace Home\Logic;

use Think\Model\RelationModel;
/**
 * 
 * Class adLogic
 * @package Home\Logic
 */
class AdLogic extends RelationModel
{

}