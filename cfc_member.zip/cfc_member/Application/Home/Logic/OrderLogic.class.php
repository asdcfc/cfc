<?php


namespace Home\Logic;

use Think\Model\RelationModel;
/**
 *
 * Class orderLogic
 * @package Home\Logic
 */
class OrderLogic extends RelationModel
{

}