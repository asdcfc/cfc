delete  from `__PREFIX__system_module` where ctl = 'HelloWorld';
drop table `__PREFIX__hello_world`;