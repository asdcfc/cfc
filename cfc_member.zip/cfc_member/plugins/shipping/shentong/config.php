<?php

return array(
    'code'=> 'shentong',
    'name' => '申通物流',
    'version' => '1.0',
    'author' => '宇宙人',
    'desc' => '申通物流插件 ',
    'icon' => 'logo.jpg',
);