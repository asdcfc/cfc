<?php

return array(
    'code'=> 'bestexpress',
    'name' => '百世汇通',
    'version' => '1.0',
    'author' => 'bestexpress',
    'desc' => '百世汇通插件 ',
    'icon' => 'logo.jpg',
);