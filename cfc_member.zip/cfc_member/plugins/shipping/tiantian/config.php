<?php

return array(
    'code'=> 'tiantian',
    'name' => '天天物流',
    'version' => '1.0',
    'author' => 'tiantian',
    'desc' => '天天快递插件 ',
    'icon' => 'logo.jpg',
);