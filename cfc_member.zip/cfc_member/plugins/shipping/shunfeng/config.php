<?php

return array(
    'code'=> 'shunfeng',
    'name' => '顺丰物流',
    'version' => '1.0',
    'author' => 'shunfeng',
    'desc' => '顺丰物流插件 ',
    'icon' => 'logo.jpg',
);