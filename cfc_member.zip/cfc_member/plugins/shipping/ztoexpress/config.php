<?php

return array(
    'code'=> 'ztoexpress',
    'name' => '中通快递',
    'version' => '1.0',
    'author' => 'ztoexpress',
    'desc' => '中通快递插件 ',
    'icon' => 'logo.jpg',
);